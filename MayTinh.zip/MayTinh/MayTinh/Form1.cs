using System;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace MayTinh
{
    public partial class Form1 : Form
    {
        double a = 0;
        string pheptoan = "";

        TcpClient client;
        NetworkStream stream;
        bool daKetNoi = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtIP.Text = "127.0.0.1";
            txtPort.Text = "5000";

            lblStatus.Text = "Chưa kết nối";

            btnHistory.Visible = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtIP_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPort_TextChanged(object sender, EventArgs e)
        {

        }

        private void So_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            textBox1.Text += btn.Text;
        }

        private void PhepToan_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
                return;

            Button btn = sender as Button;

            a = double.Parse(textBox1.Text);
            pheptoan = btn.Text;

            textBox1.Clear();
        }

        private void btnBang_Click(object sender, EventArgs e)
        {
            if (!daKetNoi)
            {
                MessageBox.Show("Hãy kết nối Server trước!");
                return;
            }

            if (textBox1.Text == "")
                return;

            double b = double.Parse(textBox1.Text);

            try
            {
                string dulieu =
                    a + "|" + pheptoan + "|" + b;

                byte[] gui =
                    Encoding.UTF8.GetBytes(dulieu);

                stream.Write(gui, 0, gui.Length);

                byte[] nhan =
                    new byte[1024];

                int data =
                    stream.Read(nhan, 0, nhan.Length);

                string ketqua =
                    Encoding.UTF8.GetString(
                        nhan,
                        0,
                        data
                    );

                textBox1.Text = ketqua;

                string lichsu =
                    a + " " +
                    pheptoan + " " +
                    b + " = " +
                    ketqua;

                btnHistory.Items.Add(lichsu);
            }
            catch
            {
                MessageBox.Show("Lỗi gửi dữ liệu!");
            }
        }

        private void btnC_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void btnDoiDau_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                double value =
                    double.Parse(textBox1.Text);

                value = -value;

                textBox1.Text =
                    value.ToString();
            }
        }

        private void btnshowHistory_Click(object sender, EventArgs e)
        {
            btnHistory.Visible =
        !btnHistory.Visible;

            if (btnHistory.Visible)
            {
                btnHistory.BringToFront();
            }
        }

        private void btnHistory_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (btnHistory.SelectedItem != null)
            {
                string item =
                    btnHistory.SelectedItem.ToString();

                string[] parts =
                    item.Split('=');

                textBox1.Text =
                    parts[1].Trim();
            }

            btnHistory.Visible = false;
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                string ip =
                    txtIP.Text;

                int port =
                    int.Parse(txtPort.Text);

                client =
                    new TcpClient(ip, port);

                stream =
                    client.GetStream();

                daKetNoi = true;

                lblStatus.Text =
                    "Đã kết nối Server";

                MessageBox.Show(
                    "Kết nối thành công!"
                );
            }
            catch
            {
                lblStatus.Text =
                    "Mất kết nối";

                MessageBox.Show(
                    "Không kết nối được Server!"
                );
            }
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            try
            {
                if (stream != null)
                    stream.Close();

                if (client != null)
                    client.Close();

                daKetNoi = false;

                lblStatus.Text =
                    "Đã ngắt kết nối";

                MessageBox.Show(
                    "Ngắt kết nối thành công!"
                );
            }
            catch
            {
                MessageBox.Show(
                    "Lỗi khi ngắt kết nối!"
                );
            }
        }

        private void lblStatus_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            txtIP.Text = "127.0.0.1";
            txtPort.Text = "5000";

            lblStatus.Text = "Chưa kết nối";

            btnHistory.Visible = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
