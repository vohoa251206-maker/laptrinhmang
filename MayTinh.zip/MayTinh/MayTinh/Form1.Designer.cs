﻿namespace MayTinh
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn0 = new Button();
            textBox1 = new TextBox();
            txtIP = new TextBox();
            txtPort = new TextBox();
            btn1 = new Button();
            btn2 = new Button();
            btn3 = new Button();
            btn4 = new Button();
            btn5 = new Button();
            btn6 = new Button();
            btn7 = new Button();
            btn8 = new Button();
            btn9 = new Button();
            btnCong = new Button();
            btnTru = new Button();
            btnNhan = new Button();
            btnChia = new Button();
            btnBang = new Button();
            btnC = new Button();
            btnDoiDau = new Button();
            btnshowHistory = new Button();
            btnHistory = new ListBox();
            btnConnect = new Button();
            btnDisconnect = new Button();
            lblStatus = new Label();
            panel1 = new Panel();
            label1 = new Label();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // btn0
            // 
            btn0.Location = new Point(103, 267);
            btn0.Name = "btn0";
            btn0.Size = new Size(94, 29);
            btn0.TabIndex = 0;
            btn0.Text = "0";
            btn0.UseVisualStyleBackColor = true;
            btn0.Click += So_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(3, 130);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(191, 27);
            textBox1.TabIndex = 1;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // txtIP
            // 
            txtIP.Location = new Point(153, 15);
            txtIP.Name = "txtIP";
            txtIP.Size = new Size(125, 27);
            txtIP.TabIndex = 2;
            txtIP.TextChanged += txtIP_TextChanged;
            // 
            // txtPort
            // 
            txtPort.Location = new Point(16, 15);
            txtPort.Name = "txtPort";
            txtPort.Size = new Size(125, 27);
            txtPort.TabIndex = 3;
            txtPort.TextChanged += txtPort_TextChanged;
            // 
            // btn1
            // 
            btn1.Location = new Point(3, 162);
            btn1.Name = "btn1";
            btn1.Size = new Size(94, 29);
            btn1.TabIndex = 4;
            btn1.Text = "1";
            btn1.UseVisualStyleBackColor = true;
            btn1.Click += So_Click;
            // 
            // btn2
            // 
            btn2.Location = new Point(103, 162);
            btn2.Name = "btn2";
            btn2.Size = new Size(94, 29);
            btn2.TabIndex = 5;
            btn2.Text = "2";
            btn2.UseVisualStyleBackColor = true;
            btn2.Click += So_Click;
            // 
            // btn3
            // 
            btn3.Location = new Point(203, 165);
            btn3.Name = "btn3";
            btn3.Size = new Size(94, 29);
            btn3.TabIndex = 6;
            btn3.Text = "3";
            btn3.UseVisualStyleBackColor = true;
            btn3.Click += So_Click;
            // 
            // btn4
            // 
            btn4.Location = new Point(3, 197);
            btn4.Name = "btn4";
            btn4.Size = new Size(94, 29);
            btn4.TabIndex = 7;
            btn4.Text = "4";
            btn4.UseVisualStyleBackColor = true;
            btn4.Click += So_Click;
            // 
            // btn5
            // 
            btn5.Location = new Point(103, 197);
            btn5.Name = "btn5";
            btn5.Size = new Size(94, 29);
            btn5.TabIndex = 8;
            btn5.Text = "5";
            btn5.UseVisualStyleBackColor = true;
            btn5.Click += So_Click;
            // 
            // btn6
            // 
            btn6.Location = new Point(203, 197);
            btn6.Name = "btn6";
            btn6.Size = new Size(94, 29);
            btn6.TabIndex = 9;
            btn6.Text = "6";
            btn6.UseVisualStyleBackColor = true;
            btn6.Click += So_Click;
            // 
            // btn7
            // 
            btn7.Location = new Point(3, 232);
            btn7.Name = "btn7";
            btn7.Size = new Size(94, 29);
            btn7.TabIndex = 10;
            btn7.Text = "7";
            btn7.UseVisualStyleBackColor = true;
            btn7.Click += So_Click;
            // 
            // btn8
            // 
            btn8.Location = new Point(103, 232);
            btn8.Name = "btn8";
            btn8.Size = new Size(94, 29);
            btn8.TabIndex = 11;
            btn8.Text = "8";
            btn8.UseVisualStyleBackColor = true;
            btn8.Click += So_Click;
            // 
            // btn9
            // 
            btn9.Location = new Point(203, 232);
            btn9.Name = "btn9";
            btn9.Size = new Size(94, 29);
            btn9.TabIndex = 12;
            btn9.Text = "9";
            btn9.UseVisualStyleBackColor = true;
            btn9.Click += So_Click;
            // 
            // btnCong
            // 
            btnCong.Location = new Point(303, 162);
            btnCong.Name = "btnCong";
            btnCong.Size = new Size(94, 31);
            btnCong.TabIndex = 13;
            btnCong.Text = "+";
            btnCong.UseVisualStyleBackColor = true;
            btnCong.Click += PhepToan_Click;
            // 
            // btnTru
            // 
            btnTru.Location = new Point(303, 197);
            btnTru.Name = "btnTru";
            btnTru.Size = new Size(94, 29);
            btnTru.TabIndex = 14;
            btnTru.Text = "-";
            btnTru.UseVisualStyleBackColor = true;
            btnTru.Click += PhepToan_Click;
            // 
            // btnNhan
            // 
            btnNhan.Location = new Point(303, 232);
            btnNhan.Name = "btnNhan";
            btnNhan.Size = new Size(94, 29);
            btnNhan.TabIndex = 15;
            btnNhan.Text = "*";
            btnNhan.UseVisualStyleBackColor = true;
            btnNhan.Click += PhepToan_Click;
            // 
            // btnChia
            // 
            btnChia.Location = new Point(303, 266);
            btnChia.Name = "btnChia";
            btnChia.Size = new Size(94, 29);
            btnChia.TabIndex = 16;
            btnChia.Text = "/";
            btnChia.UseVisualStyleBackColor = true;
            btnChia.Click += PhepToan_Click;
            // 
            // btnBang
            // 
            btnBang.Location = new Point(3, 266);
            btnBang.Name = "btnBang";
            btnBang.Size = new Size(94, 29);
            btnBang.TabIndex = 17;
            btnBang.Text = "=";
            btnBang.UseVisualStyleBackColor = true;
            btnBang.Click += btnBang_Click;
            // 
            // btnC
            // 
            btnC.Location = new Point(203, 130);
            btnC.Name = "btnC";
            btnC.Size = new Size(94, 29);
            btnC.TabIndex = 18;
            btnC.Text = "C";
            btnC.UseVisualStyleBackColor = true;
            btnC.Click += btnC_Click;
            // 
            // btnDoiDau
            // 
            btnDoiDau.Location = new Point(303, 130);
            btnDoiDau.Name = "btnDoiDau";
            btnDoiDau.Size = new Size(94, 29);
            btnDoiDau.TabIndex = 19;
            btnDoiDau.Text = "+/-";
            btnDoiDau.UseVisualStyleBackColor = true;
            btnDoiDau.Click += btnDoiDau_Click;
            // 
            // btnshowHistory
            // 
            btnshowHistory.Location = new Point(203, 266);
            btnshowHistory.Name = "btnshowHistory";
            btnshowHistory.Size = new Size(94, 29);
            btnshowHistory.TabIndex = 20;
            btnshowHistory.Text = "Hist";
            btnshowHistory.UseVisualStyleBackColor = true;
            btnshowHistory.Click += btnshowHistory_Click;
            // 
            // btnHistory
            // 
            btnHistory.FormattingEnabled = true;
            btnHistory.Location = new Point(3, 302);
            btnHistory.Name = "btnHistory";
            btnHistory.Size = new Size(394, 104);
            btnHistory.TabIndex = 21;
            btnHistory.Click += btnHistory_SelectedIndexChanged;
            // 
            // btnConnect
            // 
            btnConnect.Location = new Point(16, 48);
            btnConnect.Name = "btnConnect";
            btnConnect.Size = new Size(125, 29);
            btnConnect.TabIndex = 22;
            btnConnect.Text = "Server";
            btnConnect.UseVisualStyleBackColor = true;
            btnConnect.Click += btnConnect_Click;
            // 
            // btnDisconnect
            // 
            btnDisconnect.Location = new Point(153, 48);
            btnDisconnect.Name = "btnDisconnect";
            btnDisconnect.Size = new Size(125, 29);
            btnDisconnect.TabIndex = 23;
            btnDisconnect.Text = "Disconnect";
            btnDisconnect.UseVisualStyleBackColor = true;
            btnDisconnect.Click += btnDisconnect_Click;
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(16, 93);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(92, 20);
            lblStatus.TabIndex = 24;
            lblStatus.Text = "Chưa kết nối";
            lblStatus.Click += lblStatus_Click;
            // 
            // panel1
            // 
            panel1.Controls.Add(label1);
            panel1.Controls.Add(btnshowHistory);
            panel1.Controls.Add(btnHistory);
            panel1.Controls.Add(lblStatus);
            panel1.Controls.Add(btnConnect);
            panel1.Controls.Add(btnDisconnect);
            panel1.Controls.Add(txtPort);
            panel1.Controls.Add(btnC);
            panel1.Controls.Add(txtIP);
            panel1.Controls.Add(btnDoiDau);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(btnCong);
            panel1.Controls.Add(btnTru);
            panel1.Controls.Add(btn1);
            panel1.Controls.Add(btn0);
            panel1.Controls.Add(btn3);
            panel1.Controls.Add(btnBang);
            panel1.Controls.Add(btn4);
            panel1.Controls.Add(btnChia);
            panel1.Controls.Add(btn5);
            panel1.Controls.Add(btnNhan);
            panel1.Controls.Add(btn7);
            panel1.Controls.Add(btn8);
            panel1.Controls.Add(btn2);
            panel1.Controls.Add(btn6);
            panel1.Controls.Add(btn9);
            panel1.Location = new Point(159, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(407, 426);
            panel1.TabIndex = 25;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(16, 22);
            label1.Name = "label1";
            label1.Size = new Size(0, 20);
            label1.TabIndex = 25;
            label1.Click += label1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(panel1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load_1;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button btn0;
        private TextBox textBox1;
        private TextBox txtIP;
        private TextBox txtPort;
        private Button btn1;
        private Button btn2;
        private Button btn3;
        private Button btn4;
        private Button btn5;
        private Button btn6;
        private Button btn7;
        private Button btn8;
        private Button btn9;
        private Button btnCong;
        private Button btnTru;
        private Button btnNhan;
        private Button btnChia;
        private Button btnBang;
        private Button btnC;
        private Button btnDoiDau;
        private Button btnshowHistory;
        private ListBox btnHistory;
        private Button btnConnect;
        private Button btnDisconnect;
        private Label lblStatus;
        private Panel panel1;
        private Label label1;
    }
}
